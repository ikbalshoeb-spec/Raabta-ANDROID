package com.shoaib.raabta;
import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.os.*;
import java.io.*;
/** CI-only screen capture. Runs on an empty emulator, never on the user's phone. */
public class DesignCapture extends Instrumentation {
 @Override public void onCreate(Bundle b){super.onCreate(b);start();}
 @Override public void onStart(){Bundle result=new Bundle();try{
  Store.prefs(getTargetContext()).edit().putBoolean("onboarded",true).putBoolean("prayers",false).commit();
  MainActivity a=(MainActivity)startActivitySync(new Intent(getTargetContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  for(String page:new String[]{"Aaj","Calendar","Namaz","Settings"}){runOnMainSync(()->{a.page=page;a.show();});waitForIdleSync();SystemClock.sleep(500);Bitmap bitmap=getUiAutomation().takeScreenshot();if(bitmap==null)throw new IllegalStateException("Screenshot missing");File dir=new File(getTargetContext().getExternalFilesDir(null),"design");dir.mkdirs();try(FileOutputStream out=new FileOutputStream(new File(dir,page+".png"))){bitmap.compress(Bitmap.CompressFormat.PNG,100,out);}bitmap.recycle();}
  result.putString("stream","All four Raabta screens rendered without crashes.\n");finish(Activity.RESULT_OK,result);
 }catch(Throwable error){result.putString("stream","DESIGN CHECK FAILED: "+error);finish(Activity.RESULT_CANCELED,result);}}
}
