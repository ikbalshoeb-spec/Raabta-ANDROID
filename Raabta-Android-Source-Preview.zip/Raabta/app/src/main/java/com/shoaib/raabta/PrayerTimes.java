package com.shoaib.raabta;
import android.content.*;
import org.json.*;
import java.time.*;
import java.net.*;
import java.io.*;
import java.util.*;
final class PrayerTimes {
 static final String[] NAMES={"Fajr","Zuhr","Asr","Maghrib","Isha"};
 static final String[] KEYS={"Fajr","Dhuhr","Asr","Maghrib","Isha"};
 static JSONObject day(Context c,LocalDate d){try{return new JSONObject(Store.prefs(c).getString("prayer_"+d,"{}"));}catch(Exception e){return new JSONObject();}}
 static long at(JSONObject o,String key,LocalDate d){try{return Store.millis(d,LocalTime.parse(o.getString(key).substring(0,5)));}catch(Exception e){return 0;}}
 static long[][] windows(Context c,LocalDate d){JSONObject p=day(c,d);long[][] out=new long[5][2];for(int i=0;i<5;i++){out[i][0]=at(p,KEYS[i],d);out[i][1]=i==0?at(p,"Sunrise",d):i==4?at(day(c,d.plusDays(1)),"Fajr",d.plusDays(1)):at(p,KEYS[i+1],d);}return out;}
 static synchronized void refresh(Context c) throws Exception {
  LocalDate now=Store.today();for(int m=0;m<2;m++){
   LocalDate month=now.withDayOfMonth(1).plusMonths(m);String key="month_"+month;
   if(Store.prefs(c).getBoolean(key,false))continue;
   URL url=new URL("https://api.aladhan.com/v1/calendar/"+month.getYear()+"/"+month.getMonthValue()+"?latitude=24.8607&longitude=67.0011&method=1&school=1&timezonestring=Asia%2FKarachi");
   HttpURLConnection conn=(HttpURLConnection)url.openConnection();conn.setConnectTimeout(10000);conn.setReadTimeout(15000);
   try{
    if(conn.getResponseCode()!=200)throw new IOException("Namaz service HTTP "+conn.getResponseCode());
    StringBuilder body=new StringBuilder();try(BufferedReader reader=new BufferedReader(new InputStreamReader(conn.getInputStream(),java.nio.charset.StandardCharsets.UTF_8))){String line;while((line=reader.readLine())!=null)body.append(line);}
    JSONObject response=new JSONObject(body.toString());if(response.getInt("code")!=200)throw new IOException("Namaz service unavailable");JSONArray days=response.getJSONArray("data");
    SharedPreferences.Editor edit=Store.prefs(c).edit();for(int i=0;i<days.length();i++){JSONObject day=days.getJSONObject(i);String date=day.getJSONObject("date").getJSONObject("gregorian").getString("date");LocalDate d=LocalDate.parse(date,java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy"));JSONObject times=day.getJSONObject("timings");for(String k:new String[]{"Fajr","Sunrise","Dhuhr","Asr","Maghrib","Isha"})if(at(times,k,d)==0)throw new IOException("Invalid prayer data");edit.putString("prayer_"+d,times.toString());}edit.putBoolean(key,true).putString("prayer_error","").putLong("prayer_updated",System.currentTimeMillis()).commit();
   }finally{conn.disconnect();}
  }
  // Cache bounded to 3 months; no stale dates substituted for missing days.
  SharedPreferences.Editor clean=Store.prefs(c).edit();for(String k:Store.prefs(c).getAll().keySet())if(k.startsWith("prayer_20")){try{if(LocalDate.parse(k.substring(7)).isBefore(now.minusDays(7)))clean.remove(k);}catch(Exception ignored){}}clean.commit();
 }
}
