package com.shoaib.raabta;
import android.content.*;
import android.app.NotificationManager;
public class ReminderReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){if("done".equals(i.getAction())){String id=i.getStringExtra("id");if(id!=null){Store.done(c,id);c.getSystemService(NotificationManager.class).cancel(id.hashCode());}Engine.schedule(c);return;}Engine.tick(c);PrayerJob.register(c);}
}
