package com.shoaib.raabta;
import android.content.*;
import org.json.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
final class Store {
 static final ZoneId Z=ZoneId.of("Asia/Karachi");
 static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences("raabta",0);}
 static synchronized JSONArray items(Context c){try{return new JSONArray(prefs(c).getString("items","[]"));}catch(Exception e){return new JSONArray();}}
 static synchronized void save(Context c,JSONArray a){prefs(c).edit().putString("items",a.toString()).commit();}
 static void put(JSONObject o,String k,Object v){try{o.put(k,v);}catch(JSONException e){throw new IllegalArgumentException(e);}}
 static synchronized void add(Context c,JSONObject o){JSONArray a=items(c);a.put(o);save(c,a);}
 static synchronized void done(Context c,String id){JSONArray a=items(c);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o.optString("id").equals(id))put(o,"done",true);}save(c,a);}
 static long millis(LocalDate d,LocalTime t){return d.atTime(t).atZone(Z).toInstant().toEpochMilli();}
 static LocalDate today(){return LocalDate.now(Z);}
 static String fmt(long t){return Instant.ofEpochMilli(t).atZone(Z).format(DateTimeFormatter.ofPattern("dd MMM, hh:mm a",Locale.ENGLISH));}
}
