package com.shoaib.raabta;

import android.app.*;
import android.content.*;
import android.os.*;
import android.speech.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/** A user-controlled voice session; short provider timeouts do not close the dialog. */
final class VoiceInput implements RecognitionListener {
 private final MainActivity activity;
 private final Handler handler = new Handler(Looper.getMainLooper());
 private SpeechRecognizer recognizer;
 private AlertDialog dialog;
 private TextView status, transcript;
 private Button finish;
 private String committed = "", partial = "";
 private boolean closed, finishing;
 private long deadline;
 VoiceInput(MainActivity activity) { this.activity = activity; }
 void show() {
  if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
   activity.toast("Speech service available nahi. Phone ki Google speech service check karein."); return;
  }
  LinearLayout body = activity.box();
  status = activity.text("Tayyar ho jayein... 3", 20);
  body.addView(status);
  body.addView(activity.text("3 second baad microphone shuru hoga. Aaram se bolein; darmiyan mein ruk bhi sakte hain. Phir ‘Ho gaya’ dabayein.", 14));
  transcript = activity.text("Aap ke alfaaz yahan nazar aayenge.", 17);
  transcript.setMinHeight(activity.dp(112));
  transcript.setPadding(0, activity.dp(16), 0, activity.dp(16));
  ScrollView words = new ScrollView(activity);
  words.addView(transcript);
  body.addView(words, new LinearLayout.LayoutParams(-1, activity.dp(176)));
  dialog = new AlertDialog.Builder(activity).setTitle("Bol kar reminder")
   .setView(body).setNegativeButton("Cancel", (d,w)->close())
   .setPositiveButton("Ho gaya", null).create();
  dialog.setOnDismissListener(d->close());
  dialog.show();
  finish = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
  finish.setEnabled(false);
  finish.setOnClickListener(v->finishInput());
  handler.postDelayed(()->{if(!closed)status.setText("Tayyar ho jayein... 2");},1000);
  handler.postDelayed(()->{if(!closed)status.setText("Tayyar ho jayein... 1");},2000);
  handler.postDelayed(()->{
   if(closed)return;
   deadline = SystemClock.elapsedRealtime()+45000;
   listen();
   handler.postDelayed(this::finishInput,45000);
  },3000);
 }
 private void listen() {
  if(closed||finishing)return;
  if(SystemClock.elapsedRealtime()>=deadline){finishInput();return;}
  if(recognizer!=null){recognizer.destroy();recognizer=null;}
  recognizer=SpeechRecognizer.createSpeechRecognizer(activity);
  recognizer.setRecognitionListener(this);
  Intent intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
  intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
  intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ur-PK");
  intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
  // Providers may ignore these hints; session restart below also handles early silence.
  intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,5000L);
  intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS,5000L);
  intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS,15000L);
  status.setText("Microphone tayyar ho raha hai...");
  try{recognizer.startListening(intent);}catch(RuntimeException e){fail("Microphone shuru nahi hua. Dobara try karein.");}
 }
 private String words(Bundle data) {
  ArrayList<String> words=data==null?null:data.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
  return words==null||words.isEmpty()?"":words.get(0).trim();
 }
 private String combined(){return (committed+" "+partial).trim();}
 private void render(){String value=combined();transcript.setText(value.isEmpty()?"Aap ke alfaaz yahan nazar aayenge.":value);finish.setEnabled(!value.isEmpty());}
 private void restart(){if(!closed&&!finishing){status.setText("Aaram se bolein — main sun raha hoon...");handler.postDelayed(this::listen,350);}}
 private void finishInput(){
  if(closed||finishing)return;
  finishing=true;handler.removeCallbacksAndMessages(null);
  status.setText("Alfaaz mukammal ho rahe hain...");finish.setEnabled(false);
  if(recognizer!=null)recognizer.stopListening();
  handler.postDelayed(this::deliver,1800);
 }
 private void deliver(){
  if(closed)return;
  String value=combined();close();dialog.dismiss();
  if(value.isEmpty())activity.toast("Awaaz samajh nahi aayi. Dobara bolein ya likh kar add karein.");
  else activity.review(InputParser.parse(value,Store.today()));
 }
 private void fail(String message){close();dialog.dismiss();activity.toast(message);}
 void close(){if(closed)return;closed=true;handler.removeCallbacksAndMessages(null);if(recognizer!=null){recognizer.cancel();recognizer.destroy();recognizer=null;}}
 @Override public void onReadyForSpeech(Bundle b){if(!closed&&!finishing)status.setText("Ab bolein — aap ke paas 45 second hain");}
 @Override public void onBeginningOfSpeech(){if(!closed&&!finishing)status.setText("Sun raha hoon... ho jaye to ‘Ho gaya’ dabayein");}
 @Override public void onEndOfSpeech(){if(!closed&&!finishing)status.setText("Aap ke alfaaz samajh raha hoon...");}
 @Override public void onPartialResults(Bundle b){if(closed)return;partial=words(b);render();}
 @Override public void onResults(Bundle b){if(closed)return;String result=words(b);if(result.isEmpty())result=partial;if(!result.isEmpty())committed=(committed+" "+result).trim();partial="";render();if(finishing)deliver();else restart();}
 @Override public void onError(int error){
  if(closed)return;
  if(finishing){deliver();return;}
  if(error==SpeechRecognizer.ERROR_NO_MATCH||error==SpeechRecognizer.ERROR_SPEECH_TIMEOUT){if(!partial.isEmpty()){committed=combined();partial="";render();}restart();}
  else if(error==SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS)fail("Microphone ki permission dein.");
  else fail("Speech service se rabta nahi hua. Internet aur microphone check karke dobara try karein.");
 }
 @Override public void onRmsChanged(float rms){}
 @Override public void onBufferReceived(byte[] buffer){}
 @Override public void onEvent(int type,Bundle data){}
}
