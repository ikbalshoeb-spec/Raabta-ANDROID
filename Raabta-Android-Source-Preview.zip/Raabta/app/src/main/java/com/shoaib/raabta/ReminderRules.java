package com.shoaib.raabta;
import java.time.*;
import java.util.*;
final class ReminderRules {
 static final ZoneId KARACHI=ZoneId.of("Asia/Karachi");
 static List<Long> meetingTimes(long start,LocalTime morning){
  TreeSet<Long> out=new TreeSet<>();LocalDate date=Instant.ofEpochMilli(start).atZone(KARACHI).toLocalDate();long summary=date.atTime(morning).atZone(KARACHI).toInstant().toEpochMilli();if(summary<start)out.add(summary);for(int before=60;before>=0;before-=15)out.add(start-before*60000L);return new ArrayList<>(out);
 }
 static long nextTask(long deliveredAt){return deliveredAt+30*60000L;}
}
