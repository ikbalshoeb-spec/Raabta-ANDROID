package com.shoaib.raabta;
import android.app.job.*;
import android.content.*;
public class PrayerJob extends JobService {
 static void register(Context c){JobScheduler js=c.getSystemService(JobScheduler.class);if(js.getPendingJob(40)==null)js.schedule(new JobInfo.Builder(40,new ComponentName(c,PrayerJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true).setPeriodic(24*60*60*1000L).build());}
 @Override public boolean onStartJob(JobParameters p){new Thread(()->{boolean retry=false;try{PrayerTimes.refresh(this);}catch(Exception e){Store.prefs(this).edit().putString("prayer_error","Timings refresh nahi hue; internet check karein.").commit();retry=true;}Engine.schedule(this);jobFinished(p,retry);}).start();return true;}
 @Override public boolean onStopJob(JobParameters p){return true;}
}
