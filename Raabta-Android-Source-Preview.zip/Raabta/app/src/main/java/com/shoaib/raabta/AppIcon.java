package com.shoaib.raabta;
import android.content.Context;
import android.graphics.*;
import android.view.View;
/** Small resolution-independent line icons, drawn on the native Android canvas. */
public final class AppIcon extends View {
 private final String name;private final int color,size;private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
 public AppIcon(Context c,String n,int color,int size){super(c);this.name=n;this.color=color;this.size=size;setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
 @Override protected void onMeasure(int w,int h){setMeasuredDimension(resolveSize(size,w),resolveSize(size,h));}
 void line(Canvas c,float x,float y,float xx,float yy){c.drawLine(x,y,xx,yy,p);}
 void path(Canvas c,float... points){Path v=new Path();v.moveTo(points[0],points[1]);for(int i=2;i<points.length;i+=2)v.lineTo(points[i],points[i+1]);c.drawPath(v,p);}
 @Override protected void onDraw(Canvas c){super.onDraw(c);c.save();c.scale(getWidth()/24f,getHeight()/24f);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.7f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
 switch(name){
 case "home":path(c,3,10,12,3,21,10);path(c,5,9,5,21,10,21,10,15,14,15,14,21,19,21,19,9);break;
 case "calendar":c.drawRoundRect(3,5,21,21,3,3,p);line(c,3,10,21,10);line(c,8,3,8,7);line(c,16,3,16,7);line(c,7,14,9,14);line(c,15,14,17,14);line(c,7,18,9,18);break;
 case "moon":Path m=new Path();m.moveTo(18,3);m.cubicTo(5,-1,0,12,7,19);m.cubicTo(12,24,22,20,22,13);m.cubicTo(13,18,9,8,18,3);c.drawPath(m,p);break;
 case "settings":c.drawCircle(12,12,7,p);c.drawCircle(12,12,2.6f,p);for(int i=0;i<8;i++){c.save();c.rotate(i*45,12,12);line(c,12,2,12,4);c.restore();}break;
 case "check":c.drawCircle(12,12,9,p);path(c,7,12,10.5f,15.5f,17,8.5f);break;
 case "spark":path(c,12,2,14.5f,9.5f,22,12,14.5f,14.5f,12,22,9.5f,14.5f,2,12,9.5f,9.5f,12,2);break;
 default:p.setStrokeWidth(3);c.drawArc(3,4,15,16,60,290,false,p);c.drawArc(9,8,21,20,240,290,false,p);break;
 }c.restore();}
}
