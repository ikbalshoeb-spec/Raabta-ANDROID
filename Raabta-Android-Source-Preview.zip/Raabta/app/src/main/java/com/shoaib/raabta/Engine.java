package com.shoaib.raabta;
import android.app.*;
import android.content.*;
import android.os.Build;
import android.net.Uri;
import android.media.AudioAttributes;
import java.time.*;
import java.util.*;
import org.json.*;
final class Engine {
 static final long MIN=60000;
 static final class Event {String key,title,body,item;long when;boolean prayer;Event(String k,long w,String t,String b,String id,boolean p){key=k;when=w;title=t;body=b;item=id;prayer=p;}}
 static List<Event> events(Context c,long now){
  ArrayList<Event> out=new ArrayList<>();JSONArray items=Store.items(c);
  for(int i=0;i<items.length();i++){JSONObject o=items.optJSONObject(i);if(o.optBoolean("done"))continue;String id=o.optString("id"),title=o.optString("title");long t=o.optLong("when");
   if(!o.optBoolean("meeting")){long next=o.optLong("next",t);out.add(new Event("task_"+id+"_"+next,next,title,"Kaam baqi hai • har 30 minute, Done tak",id,false));}
   else {LocalTime morning=LocalTime.parse(Store.prefs(c).getString("morning","07:00"));for(long alert:ReminderRules.meetingTimes(t,morning)){long before=(t-alert)/MIN;out.add(new Event("meeting_"+id+"_"+alert,alert,title,before==0?"Meeting ka waqt ho gaya":before<=60?before+" minute baad • "+Store.fmt(t):"Aaj ki meeting • "+Store.fmt(t),id,false));}}
  }
  if(Store.prefs(c).getBoolean("prayers",true))for(int offset=-1;offset<=2;offset++){LocalDate d=Store.today().plusDays(offset);long[][] times=PrayerTimes.windows(c,d);for(int i=0;i<5;i++){
   long start=times[i][0],end=times[i][1];String key="prayer_"+d+"_"+i;
   if(start>0){out.add(new Event(key+"_before",start-15*MIN,PrayerTimes.NAMES[i]+" • 15 minute baqi","Abhi namaz ka waqt shuru NAHI hua",null,true));out.add(new Event(key+"_start",start,PrayerTimes.NAMES[i]+" ka waqt","Karachi • Hanafi • namaz ka waqt shuru",null,true));}
   if(end>start&&start>0)out.add(new Event(key+"_end",end-15*MIN,PrayerTimes.NAMES[i]+" • ikhtitam qareeb","Waqt ki had tak 15 minute; namaz jaldi ada karein",null,true));
  }}return out;
 }
 static boolean sent(Context c,Event e){return Store.prefs(c).getBoolean("sent_"+e.key,false);}
 static void channels(Context c){NotificationManager nm=c.getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("general","Kaam aur meetings",NotificationManager.IMPORTANCE_DEFAULT));String sound=Store.prefs(c).getString("sound","");NotificationChannel prayer=new NotificationChannel(prayerChannel(c),"Namaz reminders",NotificationManager.IMPORTANCE_DEFAULT);if(!sound.isEmpty())prayer.setSound(Uri.parse(sound),new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());nm.createNotificationChannel(prayer);}
 static String prayerChannel(Context c){return "prayer_"+Store.prefs(c).getInt("sound_version",0);}
 static PendingIntent alarm(Context c){return PendingIntent.getBroadcast(c,1,new Intent(c,ReminderReceiver.class).setAction("tick"),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static synchronized void schedule(Context c){
  long now=System.currentTimeMillis(),next=Store.millis(Store.today().plusDays(1),LocalTime.of(0,5));
  for(Event e:events(c,now))if(!sent(c,e)&&(e.when>=now||e.key.startsWith("task_")||now-e.when<10*MIN))next=Math.min(next,Math.max(now+1000,e.when));
  AlarmManager am=c.getSystemService(AlarmManager.class);try{if(Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next,alarm(c));else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next,alarm(c));}catch(SecurityException e){am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next,alarm(c));}
 }
 static synchronized void tick(Context c){
  channels(c);long now=System.currentTimeMillis();Set<String> advance=new HashSet<>();
  for(Event e:events(c,now))if(e.when<=now&&!sent(c,e)){
   boolean task=e.key.startsWith("task_");if(task||now-e.when<10*MIN)notify(c,e);
   if(task)advance.add(e.item);else Store.prefs(c).edit().putBoolean("sent_"+e.key,true).putLong("sentAt_"+e.key,now).commit();
  }
  if(!advance.isEmpty()){JSONArray a=Store.items(c);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(advance.contains(o.optString("id")))Store.put(o,"next",ReminderRules.nextTask(now));}Store.save(c,a);}
  if(PrayerTimes.day(c,Store.today()).length()==0&&Store.prefs(c).getBoolean("prayers",true)&&!Store.today().toString().equals(Store.prefs(c).getString("missing_warn",""))){notify(c,new Event("missing",now,"Namaz timings available nahi","App khol kar timings refresh karein.",null,false));Store.prefs(c).edit().putString("missing_warn",Store.today().toString()).commit();}
  SharedPreferences.Editor edit=Store.prefs(c).edit();for(Map.Entry<String,?> entry:Store.prefs(c).getAll().entrySet())if(entry.getKey().startsWith("sentAt_")&&entry.getValue() instanceof Long&&now-(Long)entry.getValue()>7*24*60*MIN){edit.remove(entry.getKey()).remove("sent_"+entry.getKey().substring(7));}edit.commit();schedule(c);
 }
 static void notify(Context c,Event e){
  if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)return;
  PendingIntent open=PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=new Notification.Builder(c,e.prayer?prayerChannel(c):"general").setSmallIcon(com.shoaib.raabta.R.drawable.icon).setContentTitle(e.title).setContentText(e.body).setStyle(new Notification.BigTextStyle().bigText(e.body)).setContentIntent(open).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE);
  if(e.item!=null){Intent done=new Intent(c,ReminderReceiver.class).setAction("done").setData(Uri.parse("raabta://done/"+e.item)).putExtra("id",e.item);b.addAction(new Notification.Action.Builder(null,"Done",PendingIntent.getBroadcast(c,0,done,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE)).build());}
  c.getSystemService(NotificationManager.class).notify(e.item!=null?e.item.hashCode():e.key.hashCode(),b.build());
 }
}
