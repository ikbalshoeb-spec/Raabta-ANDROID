package com.shoaib.raabta;
import android.content.*;
import android.database.Cursor;
import android.provider.CalendarContract;
import android.net.Uri;
import org.json.*;
import java.util.*;
final class GoogleCalendar {
 static boolean permitted(Context c){return c.checkSelfPermission("android.permission.READ_CALENDAR")==0&&c.checkSelfPermission("android.permission.WRITE_CALENDAR")==0;}
 static List<String[]> calendars(Context c){List<String[]> out=new ArrayList<>();if(!permitted(c))return out;try(Cursor cur=c.getContentResolver().query(CalendarContract.Calendars.CONTENT_URI,new String[]{"_id","account_name","calendar_displayName"},"account_type=? AND calendar_access_level>=?",new String[]{"com.google","500"},null)){while(cur!=null&&cur.moveToNext())out.add(new String[]{cur.getString(0),cur.getString(1),cur.getString(2)});}return out;}
 static boolean selectedExists(Context c,long id){for(String[] r:calendars(c))if(Long.parseLong(r[0])==id)return true;return false;}
 static void export(Context c,JSONObject o)throws Exception{
  long cal=Store.prefs(c).getLong("calendar",-1);if(!permitted(c)||!selectedExists(c,cal))throw new Exception("Google calendar select karein aur permission dein.");
  if(o.optLong("google_event",-1)>0)throw new Exception("Ye meeting pehle hi Google par bheji ja chuki hai.");
  ContentValues v=new ContentValues();v.put(CalendarContract.Events.CALENDAR_ID,cal);v.put(CalendarContract.Events.TITLE,o.optString("title"));v.put(CalendarContract.Events.DTSTART,o.optLong("when"));v.put(CalendarContract.Events.DTEND,o.optLong("when")+60*60000);v.put(CalendarContract.Events.EVENT_TIMEZONE,"Asia/Karachi");v.put(CalendarContract.Events.DESCRIPTION,"Raabta meeting: "+o.optString("id"));
  Uri u=c.getContentResolver().insert(CalendarContract.Events.CONTENT_URI,v);if(u==null)throw new Exception("Google export save nahi hua.");Store.put(o,"google_event",ContentUris.parseId(u));Store.put(o,"google_calendar",cal);
 }
 static List<String> upcoming(Context c){List<String> out=new ArrayList<>();long id=Store.prefs(c).getLong("calendar",-1);if(!permitted(c)||id<0)return out;Uri.Builder b=CalendarContract.Instances.CONTENT_URI.buildUpon();long now=System.currentTimeMillis();ContentUris.appendId(b,now);ContentUris.appendId(b,now+30L*24*60*60000);try(Cursor cur=c.getContentResolver().query(b.build(),new String[]{CalendarContract.Instances.TITLE,CalendarContract.Instances.BEGIN},CalendarContract.Instances.CALENDAR_ID+"=?",new String[]{String.valueOf(id)},CalendarContract.Instances.BEGIN+" ASC")){while(cur!=null&&cur.moveToNext())out.add(cur.getString(0)+"\n"+Store.fmt(cur.getLong(1)));}return out;}
}
