package com.shoaib.raabta;
import java.time.*;
import java.util.*;
import java.util.regex.*;
/** Conservative local grammar. Uncertain interpretations always go through the editable review. */
final class InputParser {
 static class Draft {String title,warning="";LocalDate date;LocalTime time;boolean meeting;}
 static String normalize(String s){
  String a="۰۱۲۳۴۵۶۷۸۹",b="٠١٢٣٤٥٦٧٨٩";for(int i=0;i<10;i++)s=s.replace(a.charAt(i),(char)('0'+i)).replace(b.charAt(i),(char)('0'+i));
  String[][] pairs={{"پرسوں","parson"},{"آج","aaj"},{"کل","kal"},{"صبح","subah"},{"شام","shaam"},{"رات","raat"},{"دوپہر","dopahar"},{"بجے","bajay"},{"میٹنگ","meeting"},{"پیر","monday"},{"منگل","tuesday"},{"بدھ","wednesday"},{"جمعرات","thursday"},{"جمعہ","friday"},{"ہفتہ","saturday"},{"اتوار","sunday"},{"ستمبر","september"},{"اکتوبر","october"},{"نومبر","november"},{"دسمبر","december"},{"جنوری","january"},{"فروری","february"},{"مارچ","march"},{"اپریل","april"},{"مئی","may"},{"جون","june"},{"جولائی","july"},{"اگست","august"},{"نو","9"},{"آٹھ","8"},{"سات","7"},{"دس","10"},{"گیارہ","11"},{"بارہ","12"},{"ایک","1"},{"دو","2"},{"تین","3"},{"چار","4"},{"پانچ","5"},{"چھ","6"}};
  for(String[] p:pairs)s=s.replace(p[0],p[1]);return s.toLowerCase(Locale.ROOT);
 }
 static Draft parse(String raw,LocalDate today){
  Draft d=new Draft();d.title=raw;d.date=today;String s=normalize(raw);d.meeting=s.contains("meeting")||s.contains("appointment");
  if(s.matches(".*\\b(kal|tomorrow)\\b.*"))d.date=today.plusDays(1);
  if(s.contains("parson"))d.date=today.plusDays(2);
  String[] months={"january","february","march","april","may","june","july","august","september","october","november","december"};boolean explicit=false;
  for(int m=0;m<12;m++)if(s.contains(months[m])){
   Matcher n=Pattern.compile("(\\d{1,2})\\s*(?:taarekh|tareekh|tarikh|تاریخ)?\\s*(?:ko|کی|کو)?\\s*"+months[m]).matcher(s);
   if(!n.find()){n=Pattern.compile(months[m]+"\\s*(\\d{1,2})").matcher(s);if(!n.find()){d.warning="Tareekh khud select karein.";continue;}}
   try {Matcher y=Pattern.compile("\\b(20\\d{2})\\b").matcher(s);int year=y.find()?Integer.parseInt(y.group(1)):today.getYear();d.date=LocalDate.of(year,m+1,Integer.parseInt(n.group(1)));explicit=true;}catch(Exception e){d.warning="Tareekh durust nahi; select karein.";}
  }
  String[] days={"monday","tuesday","wednesday","thursday","friday","saturday","sunday"};
  for(int i=0;i<7;i++)if(s.contains(days[i])){if(explicit&&d.date.getDayOfWeek().getValue()!=i+1)d.warning="Din aur tareekh match nahi karte. Durust tareekh select karein.";else if(!explicit)d.date=today.plusDays((i+1-today.getDayOfWeek().getValue()+7)%7);}
  Matcher t=Pattern.compile("\\b(\\d{1,2})(?::(\\d{2}))?\\s*(bajay|baje|am|pm)\\b").matcher(s);
  if(t.find()){int h=Integer.parseInt(t.group(1)),mi=t.group(2)==null?0:Integer.parseInt(t.group(2));boolean pm=s.matches(".*\\b(shaam|sham|raat|dopahar|pm)\\b.*"),am=s.matches(".*\\b(subah|am)\\b.*");if(pm&&h<12)h+=12;if(am&&h==12)h=0;try{d.time=LocalTime.of(h,mi);if(!pm&&!am&&h<=12)d.warning="Subah ya shaam? Waqt confirm karein.";}catch(Exception e){d.warning="Waqt durust nahi.";}}
  if(d.meeting&&d.time==null)d.warning="Meeting ka waqt select karein.";
  if(s.contains("saadhay")||s.contains("saarhay")||s.contains("ساڑھے")||s.contains("quarter")||s.contains("paunay")||s.contains("پونے")){d.time=null;d.warning="Waqt khud select karein.";}
  return d;
 }
}
