#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")/.."
check_output="$(mktemp -d)"
trap 'rm -rf "$check_output"' EXIT
java -m jdk.compiler/com.sun.tools.javac.Main -d "$check_output" app/src/main/java/com/shoaib/raabta/InputParser.java app/src/main/java/com/shoaib/raabta/ReminderRules.java checks/ParserChecks.java checks/ScheduleChecks.java
java -cp "$check_output" com.shoaib.raabta.ParserChecks
java -cp "$check_output" com.shoaib.raabta.ScheduleChecks
