package com.shoaib.raabta;
import java.time.*;
public class ParserChecks {
 static void require(boolean b,String why){if(!b)throw new AssertionError(why);}
 public static void main(String[] args){
  LocalDate today=LocalDate.of(2026,9,26);
  InputParser.Draft a=InputParser.parse("Monday 28 taarekh ko september ki 9 bajay subah ek meeting hai",today);
  require(a.date.equals(LocalDate.of(2026,9,28)),"Explicit date");require(LocalTime.of(9,0).equals(a.time),"9 AM");require(a.meeting,"Meeting detection");require(a.warning.isEmpty(),"Valid date weekday");
  InputParser.Draft b=InputParser.parse("Metier pharma close karna hai aaj",today);require(!b.meeting&&b.date.equals(today),"Today task");
  InputParser.Draft c=InputParser.parse("Monday 29 September subah 9 bajay meeting",today);require(c.warning.contains("match nahi"),"Weekday mismatch");
  InputParser.Draft d=InputParser.parse("kal raat 9 bajay meeting",today);require(d.date.equals(today.plusDays(1))&&d.time.equals(LocalTime.of(21,0)),"Tomorrow evening");
  InputParser.Draft e=InputParser.parse("آج صبح ۹ بجے میٹنگ",today);require(e.meeting&&LocalTime.of(9,0).equals(e.time),"Urdu recognition");
  InputParser.Draft f=InputParser.parse("kal 9 bajay meeting",today);require(!f.warning.isEmpty(),"Ambiguous time warning");
  InputParser.Draft g=InputParser.parse("31 February subah 9 bajay meeting",today);require(!g.warning.isEmpty(),"Invalid date warning");
  InputParser.Draft h=InputParser.parse("subah saadhay 9 bajay meeting",today);require(h.time==null,"Fractional time manual review");
  System.out.println("PASS: 8 parser scenarios, 11 assertions");
 }
}
