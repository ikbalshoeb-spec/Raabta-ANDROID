#!/usr/bin/env bash
set -euo pipefail
adb install -r Raabta/app/build/outputs/apk/debug/app-debug.apk
adb shell settings put system font_scale 1.0
adb shell am instrument -w com.shoaib.raabta.design/com.shoaib.raabta.DesignCapture | tee capture-result.txt
if ! grep -q 'All four Raabta screens rendered' capture-result.txt; then
 adb logcat -d -s AndroidRuntime:E
 exit 1
fi
mkdir -p design-screens
adb pull /sdcard/Android/data/com.shoaib.raabta.design/files/design/. design-screens/
