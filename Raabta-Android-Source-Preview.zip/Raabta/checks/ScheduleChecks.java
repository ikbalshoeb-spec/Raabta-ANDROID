package com.shoaib.raabta;
import java.time.*;
import java.util.*;
public class ScheduleChecks {
 public static void main(String[] args){
  ZonedDateTime start=LocalDate.of(2026,9,28).atTime(9,0).atZone(ReminderRules.KARACHI);
  List<Long> slots=ReminderRules.meetingTimes(start.toInstant().toEpochMilli(),LocalTime.of(7,0));
  List<LocalTime> actual=new ArrayList<>();for(long x:slots)actual.add(Instant.ofEpochMilli(x).atZone(ReminderRules.KARACHI).toLocalTime());
  List<LocalTime> expected=List.of(LocalTime.of(7,0),LocalTime.of(8,0),LocalTime.of(8,15),LocalTime.of(8,30),LocalTime.of(8,45),LocalTime.of(9,0));
  if(!actual.equals(expected))throw new AssertionError(actual);
  if(ReminderRules.meetingTimes(start.toInstant().toEpochMilli(),LocalTime.of(8,0)).size()!=5)throw new AssertionError("No duplicate 8AM alert");
  long late=LocalDate.of(2026,9,26).atTime(23,50).atZone(ReminderRules.KARACHI).toInstant().toEpochMilli();
  if(!Instant.ofEpochMilli(ReminderRules.nextTask(late)).atZone(ReminderRules.KARACHI).toLocalDateTime().equals(LocalDateTime.of(2026,9,27,0,20)))throw new AssertionError("Task must continue past midnight");
  System.out.println("PASS: meeting intervals, duplicate prevention, task midnight rollover");
 }
}
