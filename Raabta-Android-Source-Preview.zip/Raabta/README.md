# Raabta — native Android source preview

**Status: source preview 0.1, not a compiled APK.** Android SDK/Gradle are not available in the creation environment and downloads timed out under its network restrictions. No Android compilation, lint, emulator, Samsung installation or background delivery testing has been performed. This archive cannot be installed on a phone.

## Requested behaviour implemented in source

- Roman Urdu app interface; native Android Activities and widgets, not a website/WebView.
- Urdu device speech recognizer hands back text. English/Roman Urdu input can also be typed. A conservative local parser recognizes common dates/weekdays and AM/PM phrases. This is NOT a general AI natural-language service. User reviews editable title, task/meeting type, date and time before save. Unsupported expressions require manual date/time selection. Spoken text may remain in Urdu script.
- Meetings: default one-hour duration, configurable morning reminder default 07:00 Karachi, then 60/45/30/15 minutes before and at start. No morning summary after an early meeting. Duplicate reminder timestamps removed. Overlapping local meetings prompt before save.
- Tasks: every 30 minutes until Done, including overnight and following days. Notifications have Done. Swiping a notification away does not complete a task. No quiet hours by design.
- Local date-filtered calendar and persistent on-device entries. Mark Done stops local alerts.
- AlarmManager reminders survive ordinary app dismissal; boot, time change and package update reschedule. Permission status/setup is visible. Exact permission denied falls back to potentially delayed inexact alerts. Android/OEM restrictions may still delay delivery; never promise guaranteed timing.
- Karachi calculated prayer times from AlAdhan, method=1 and school=1, latitude 24.8607 longitude 67.0011, Asia/Karachi. Cache current and following month; a daily network job refreshes. No invented fallback times. Isha's end uses the following day's Fajr. UI distinguishes the boundary of time from preferred prayer time; actual mosque jamaat schedules are not provided.
- Prayer notices 15 minutes before start, at start, 15 minutes before end. Pre-start message explicitly says prayer time has not started. A single notification sound plays, not a continuous alarm.
- Takbir: user taps Generate in Settings to synthesize “الله أكبر، الله أكبر” with installed Arabic TTS. This is synthetic speech, not a human muezzin recording. If an Arabic voice is missing or generation fails, select a personal audio file. Until configured, system default tone is used. Test actual playback on the Samsung. App exposes only the generated fixed WAV through a read-only content provider.
- Optional selected Google account/calendar only: list writable `com.google` calendars, explicitly select one, opt in for each meeting export. Read upcoming 30 days from that calendar. No credentials collected; device Calendar Provider and existing Google sync handle cloud sync. Other account events are not read.

## Google scope / unfinished parts

This preview exports new meetings once and displays selected Google events. It is **not full bidirectional edit/delete synchronization**. Imported Google events are display-only; their notifications remain managed by Google Calendar. Done does not delete exported events. Disconnect stops new access but does not erase existing exports. Device Google Calendar sync must be enabled. No task-to-Google-Tasks integration. These limitations are also stated inside the app.

Other remaining work: compile/lint against Android SDK; Samsung acceptance testing; general natural-language expansion; editing/deleting saved entries beyond Done; production signing and release validation. Audio setup is explicit, not bundled or silently assumed working.

## Build an APK

Requires JDK 17, Android SDK platform 35/build tools 35.0.0, Gradle 8.9, and network access to Google Maven/Maven Central. Android Gradle plugin pinned to 8.7.3.

### Android Studio / local

1. Extract the archive; open the `Raabta` directory as the project in Android Studio.
2. Install platform 35/build tools 35.0.0 and select JDK 17. With Gradle 8.9 installed, run `gradle wrapper --gradle-version 8.9` if Studio needs a wrapper. Wrapper binaries are not included because dependencies could not be downloaded.
3. Run `bash checks/run.sh`.
4. Run `gradle :app:assembleDebug :app:lintDebug`.
5. Only after a successful build, find `app/build/outputs/apk/debug/app-debug.apk`.

### Private GitHub repository

1. Put the **contents of Raabta** at a private repository root, including `.github/workflows/android.yml`.
2. Open Actions > Build Raabta APK > Run workflow.
3. The workflow installs toolchain, runs parser/scheduling checks, builds and lints, then uploads `Raabta-preview-APK` artifact. Fix any build/lint failures before treating it as usable.
4. Download and unzip the artifact to get the APK. This workflow has been written but not run here. No repository was created or published and no account was accessed.

The workflow uses a disposable debug signing key. Subsequent builds from different runners may not install over the first APK. Before real ongoing use, configure and retain a private release signing key; never commit that key. Uninstalling loses app data (backup intentionally disabled). Do not deploy this draft as a production release.

## First phone setup after a successful build

1. Open Settings inside Raabta. Allow notifications and Alarms & reminders.
2. On Samsung, set battery usage to Unrestricted and remove Raabta from Sleeping/Deep sleeping apps. Force stop and power-off stop delivery; reopen after force stop.
3. Generate/select Takbir audio and use Namaz notification test.
4. Open Namaz; ensure current-day and following-day data loaded.
5. Optional: enable phone Google calendar sync, grant calendar permissions and select the exact account/calendar.
6. Set morning time (default 07:00).

## Checks actually run (26 September 2026)

- Java parser compiled and executed: 8 scenarios / 11 assertions pass, including user's exact example, Urdu digits, invalid dates, weekday mismatch, missing AM/PM and fractional-time fallback.
- Pure Java meeting schedule tested: 07:00, 08:00, 08:15, 08:30, 08:45, 09:00 for Monday 28 Sep at 09:00; duplicate prevention; task 23:50 -> next day 00:20.
- All 10 Android Java sources parsed by JDK compiler parser without syntax errors. This does **not** type-check Android APIs or produce bytecode/APK.
- Android manifest and drawable XML parse successfully.

## Mandatory device acceptance before use

- Deny/grant notifications and exact alarms; status must match and there must be no crash.
- Schedule a task; verify repeated notifications with screen locked and app dismissed. Press Done; verify no later notification, including after reboot.
- Verify 15-minute meeting cadence and overlap warning. Test reboot, date/time change, permission revocation and a missed reminder.
- Check all prayer boundaries against a trusted Karachi Hanafi timetable, especially next-day Isha end and month rollover. Confirm missing data warning. Verify pre-start reminders never say prayer has started.
- Test Takbir in locked screen, with installed/missing Arabic voice, and with selected recording; respect silent/DND.
- Add two Google accounts; select one; verify only selected calendar is read/written, and cloud event arrives. Switch/disconnect and ensure other accounts remain untouched.
- Test speech recognition on actual Samsung with mixed Urdu/English, ambiguous date/time and no speech service. Confirm the date/time preview before save.

## Privacy

Entries are stored locally in app preferences and backup is off. Voice recognition may transmit audio to the phone's speech provider. AlAdhan gets public Karachi coordinates, never task text. Google gets only meetings the user explicitly exports. The app contains no advertising SDK, analytics, cloud AI key or account password.

## Technical references consulted

- https://developer.android.com/develop/background-work/services/alarms
- https://developer.android.com/about/versions/14/changes/schedule-exact-alarms
- https://developer.android.com/identity/providers/calendar-provider
- https://aladhan.com/calculation-methods
- https://aladhan.com/prayer-times-api
