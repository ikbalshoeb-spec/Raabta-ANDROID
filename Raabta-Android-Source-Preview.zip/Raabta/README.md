# Raabta 2 — native Android redesign

Warm ivory / forest green UI, line icons, bottom navigation, voice card, overview counts, task cards, week selector, prayer cards and grouped settings. Existing reminder engine, parser and calendar logic are unchanged.

This design build installs alongside the original Raabta to preserve its entries. The original CI debug signing key was ephemeral and is unavailable, so a data-preserving replacement of that installed app cannot be signed. No automatic transfer between the two apps is performed. The new package is com.shoaib.raabta.design. Build workflow caches this development signing key for later test updates, but cache retention is not production key storage.

Source archive is extracted by the root GitHub Actions workflow. Build with Gradle 8.9, JDK 17, Android SDK 35. Run bash checks/run.sh for schedule/parser checks. CI also launches all four screens on an emulator and captures screenshots using debug-only instrumentation.

First use: grant notifications and exact alarms; set Samsung battery to Unrestricted; generate or select Takbir audio and run its notification test. Google calendar is optional and account-selected. Speech is local-rule parsing after system Urdu recognition and requires date/time confirmation. Google export/read is not full bidirectional edit/delete sync. Prayer calculation: Karachi method 1, Hanafi school 1, with next-day Fajr as Isha boundary. Force-stop or phone power-off prevents reminders.

No personal entries, credentials, or signing secrets are in this source archive.
